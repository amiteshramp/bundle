import os
import sys
import uuid
from datetime import datetime

from airflow.models import DAG
from airflow.providers.apache.spark.operators.spark_submit import SparkSubmitOperator

from config_management_pkg.config_management import get_config_data

# Due to utils package import issue do not move the below import line to other location
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
import utils

ROOT_PATH = os.path.join(os.path.dirname(os.path.realpath(__file__)))
APP_CONSTANT_MS_NAME = "analytics-ask-leni"

props = get_config_data(ROOT_PATH, APP_CONSTANT_MS_NAME)

connections = utils.load_connections(props)

spark_storage_claimname = props.get("spark_storage_claimname")
spark_storage_claimpath = props.get("spark_storage_claimpath")
spark_storage_volumetype = props.get("spark_storage_volumetype")
spark_eventLog_dir = props.get("spark_eventLog_dir")
spark_serviceaccount = props.get("spark_serviceaccount")
spark_driver_volume_claimname = f"spark.kubernetes.driver.volumes.{spark_storage_volumetype}.{spark_storage_claimname}.options.claimName"
spark_driver_volume_claimpath = f"spark.kubernetes.driver.volumes.{spark_storage_volumetype}.{spark_storage_claimname}.mount.path"
spark_executor_volume_claimname = f"spark.kubernetes.executor.volumes.{spark_storage_volumetype}.{spark_storage_claimname}.options.claimName"
spark_executor_volume_claimpath = f"spark.kubernetes.executor.volumes.{spark_storage_volumetype}.{spark_storage_claimname}.mount.path"

with DAG(
        dag_id="test_spark_operator",
        schedule_interval=None,
        start_date=datetime(2021, 1, 1),
        catchup=False,
        tags=["tests"],
) as dag:
    submit_job = SparkSubmitOperator(
        task_id="submit_job",
        name="spark-pi",
        conn_id=connections.get("spark_master"),
        conf={
            "spark.driver.memory": "1gb",
            "spark.executor.instances": "2",
            "spark.executor.memory": "1gb",
            "spark.executor.cores": "3",
            "spark.eventLog.enabled": True,
            "spark.eventLog.dir": spark_eventLog_dir,
            spark_driver_volume_claimname: spark_storage_claimname,
            spark_driver_volume_claimpath: spark_storage_claimpath,
            spark_executor_volume_claimname: spark_storage_claimname,
            spark_executor_volume_claimpath: spark_storage_claimpath,
            "spark.kubernetes.driver.pod.name": "{{ dag_run.conf['name'] }}",
            "spark.kubernetes.executor.podNamePrefix": "{{ dag_run.conf['name'] }}",
            "spark.kubernetes.driver.label.pi-driver": True,
            "spark.kubernetes.executor.label.pi-executor": True,
            "spark.kubernetes.executor.limit.cores": "3",
            "spark.kubernetes.driver.limit.cores": "1",
            "spark.kubernetes.driver.request.cores": "1",
            "spark.kubernetes.container.image": "826422597116.dkr.ecr.us-east-1.amazonaws.com/spark:3.1.2",
            "spark.kubernetes.authenticate.driver.serviceAccountName": spark_serviceaccount
        },
        application="${SPARK_HOME}/examples/src/main/python/pi.py"
    )
