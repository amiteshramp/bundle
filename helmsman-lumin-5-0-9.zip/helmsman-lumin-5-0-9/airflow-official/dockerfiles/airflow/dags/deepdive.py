import os
import sys
from airflow.models import DAG
from airflow.providers.http.operators.http import SimpleHttpOperator
from airflow.utils.dates import datetime
from datetime import timedelta

from config_management_pkg.config_management import get_config_data

# Due to utils package import issue do not move the below import line to other location
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
import utils

ROOT_PATH = os.path.join(os.path.dirname(os.path.realpath(__file__)))
#app_env = utils.load_configs(os.path.join(ROOT_PATH, "app.env"))
#source = app_env.get("CONFIG_MANAGEMENT_SOURCE")
#cloud_env_file_path = os.path.join(ROOT_PATH, "app-" + source + ".env")
APP_CONSTANT_MS_NAME = "analytics-ask-leni"
props = get_config_data(path=ROOT_PATH, ms_name=APP_CONSTANT_MS_NAME)
connections = utils.load_connections(props)

env = props.get("env").replace("-", "_")
analytics_s3_env_dir = props["analytics_s3_env_dir"].lower()

http_ask_leni_conn_id = connections.get("analytics_ask_leni_id")
fs_prefix = utils.build_fs_path()

dag_id = "deep_dive" if not env else "deep_dive_{}".format(env.lower())

dag = DAG(
    dag_id,
    schedule_interval=None,
    start_date=datetime(year=2021, month=9, day=1),
    default_args={"owner": "airflow"},
    tags=["deepdive", env]
)

delta_calculation = SimpleHttpOperator(
    task_id="delta_calculation",
    method="GET",
    http_conn_id=http_ask_leni_conn_id,
    endpoint="/analytics/v3/deepDive/delta_calculation",
    data={"jobid": "{{ dag_run.conf['jobid'] }}",
          "resourceid": "{{ dag_run.conf['resourceid'] }}",
          "eql_file_path": "/{{ dag_run.conf['eql_file_path'] }}",
          "account_id": "{{ dag_run.conf['account_id'] }}"},
    headers={"Authorization": "Bearer {{ dag_run.conf['token'] }}"},
    retries=0,
    retry_delay=timedelta(minutes=1),
    depends_on_past=False,
    dag=dag
)

# /{{ dag_run.conf['resourceid'] }}/{{ dag_run.conf['jobid'] }}/delta_calculation/output
# "focus_area[1/2/3]"
post_processing = []
post_processing_outputs = []
for i in range(1, 4):
    post_processing_focus_areas = SimpleHttpOperator(
        task_id="post_processing_focus_area" + str(i),
        method="GET",
        http_conn_id=http_ask_leni_conn_id,
        endpoint="/analytics/v3/deepDive/post_processing",
        data={"jobid": "{{ dag_run.conf['jobid'] }}",
              "resourceid": "{{ dag_run.conf['resourceid'] }}",
              "account_id": "{{ dag_run.conf['account_id'] }}",
              "input_file_path": fs_prefix + "/{{ dag_run.conf['resourceid'] }}/{{ dag_run.conf['jobid'] }}/delta_calculation/output",
              "focus_area": "focus_area" + str(i)},
        headers={"Authorization": "Bearer {{ dag_run.conf['token'] }}"},
        retries=0,
        retry_delay=timedelta(minutes=1),
        depends_on_past=False,
        dag=dag
    )
    post_processing_outputs.append(fs_prefix + "/{{ dag_run.conf['resourceid'] }}/{{ dag_run.conf['jobid'] }}/post_processing_focus_area" + str(i) + "/output")
    post_processing.append(post_processing_focus_areas)

#[
# /{{ dag_run.conf['resourceid'] }}/{{ dag_run.conf['jobid'] }}/post_processing_focus_areas1/output
# /{{ dag_run.conf['resourceid'] }}/{{ dag_run.conf['jobid'] }}/post_processing_focus_areas2/output
# /{{ dag_run.conf['resourceid'] }}/{{ dag_run.conf['jobid'] }}/post_processing_focus_areas3/output
# ]
post_processing_consolidation = SimpleHttpOperator(
    task_id="consolidating_post_processing_output",
    method="GET",
    http_conn_id=http_ask_leni_conn_id,
    endpoint="/analytics/v3/deepDive/post_processing_consolidation",
    data={"jobid": "{{ dag_run.conf['jobid'] }}",
          "resourceid": "{{ dag_run.conf['resourceid'] }}",
          "account_id": "{{ dag_run.conf['account_id'] }}",
          "input_file_paths": post_processing_outputs},
    headers={"Authorization": "Bearer {{ dag_run.conf['token'] }}"},
    retries=0,
    retry_delay=timedelta(minutes=1),
    depends_on_past=False,
    dag=dag
)

# /{{ dag_run.conf['resourceid'] }}/{{ dag_run.conf['jobid'] }}/consolidating_post_processing_output/output
# "focus_area[1/2/3]"
run_drivers = []
run_drivers_outputs = []
for i in range(1, 4):
    run_drivers_focus_areas = SimpleHttpOperator(
        task_id="run_drivers_focus_area" + str(i),
        method="GET",
        http_conn_id=http_ask_leni_conn_id,
        endpoint="/analytics/v3/deepDive/run_drivers",
        data={"jobid": "{{ dag_run.conf['jobid'] }}",
              "resourceid": "{{ dag_run.conf['resourceid'] }}",
              "account_id": "{{ dag_run.conf['account_id'] }}",
              "input_file_path": fs_prefix + "/{{ dag_run.conf['resourceid'] }}/{{ dag_run.conf['jobid'] }}/consolidating_post_processing_output/output",
              "focus_area": "focus_area" + str(i)},
        headers={"Authorization": "Bearer {{ dag_run.conf['token'] }}"},
        retries=0,
        retry_delay=timedelta(minutes=1),
        depends_on_past=False,
        dag=dag
    )
    run_drivers_outputs.append(fs_prefix + "/{{ dag_run.conf['resourceid'] }}/{{ dag_run.conf['jobid'] }}/run_drivers_focus_area" + str(i) + "/output")
    run_drivers.append(run_drivers_focus_areas)

#[
# /{{ dag_run.conf['resourceid'] }}/{{ dag_run.conf['jobid'] }}/run_drivers1/output
# /{{ dag_run.conf['resourceid'] }}/{{ dag_run.conf['jobid'] }}/run_drivers2/output
# /{{ dag_run.conf['resourceid'] }}/{{ dag_run.conf['jobid'] }}/run_drivers3/output
# headers={"Authorization": "Bearer {{ dag_run.conf['token'] }}"},
# ]
nlg = SimpleHttpOperator(
    task_id="nlg_and_consolidation",
    method="GET",
    http_conn_id=http_ask_leni_conn_id,
    endpoint="/analytics/v3/deepDive/nlg",
    data={"jobid": "{{ dag_run.conf['jobid'] }}",
          "resourceid": "{{ dag_run.conf['resourceid'] }}",
          "account_id": "{{ dag_run.conf['account_id'] }}",
          "input_file_paths": run_drivers_outputs},
    headers={"Authorization": "Bearer {{ dag_run.conf['token'] }}"},
    retries=0,
    retry_delay=timedelta(minutes=1),
    depends_on_past=False,
    dag=dag
)

delta_calculation >> post_processing >> post_processing_consolidation >> run_drivers >> nlg
