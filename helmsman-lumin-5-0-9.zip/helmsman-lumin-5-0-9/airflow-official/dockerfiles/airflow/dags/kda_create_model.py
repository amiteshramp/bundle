import os
import json
import base64
import sys
from pprint import pprint
from airflow.models import DAG
from airflow.utils.dates import days_ago

from airflow.operators.python import PythonOperator
from airflow.providers.http.operators.http import SimpleHttpOperator
from airflow.providers.apache.spark.operators.spark_submit import SparkSubmitOperator
from airflow.utils.state import State

# Due to utils package import issue do not move the below import line to other location
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
from utils import load_configs, load_connections

props = load_configs(os.path.join(os.path.dirname(os.path.realpath(__file__))))
connections = load_connections(props)

env = props.get("env").replace("-", "_")
spark_storage_claimname = props.get("spark_storage_claimname")
spark_storage_claimpath = props.get("spark_storage_claimpath")
spark_storage_volumetype = props.get("spark_storage_volumetype")
spark_eventLog_dir = props.get("spark_eventLog_dir")
spark_k8s_namespace = props.get("spark_k8s_namespace")
spark_container_image_kda = props.get("spark_container_image_kda")
spark_serviceaccount = props.get("spark_serviceaccount")
spark_driver_volume_claimname = f"spark.kubernetes.driver.volumes.{spark_storage_volumetype}.{spark_storage_claimname}.options.claimName"
spark_driver_volume_claimpath = f"spark.kubernetes.driver.volumes.{spark_storage_volumetype}.{spark_storage_claimname}.mount.path"
spark_executor_volume_claimname = f"spark.kubernetes.executor.volumes.{spark_storage_volumetype}.{spark_storage_claimname}.options.claimName"
spark_executor_volume_claimpath = f"spark.kubernetes.executor.volumes.{spark_storage_volumetype}.{spark_storage_claimname}.mount.path"

dag_id = "kda_create_model" if not env else "kda_create_model_{}".format(env.lower())


def _construct_spark_app_name_(conf):
    return f"kda-{conf.get('model_id')}"


def _construct_app_args_(conf):
    conf["dremio_port"] = props.get("db_dremio_jdbc_port")
    conf["dremio_host"] = props.get("db_dremio_host")
    conf["dremio_username"] = props.get("db_dremio_username")
    conf["dremio_password"] = props.get("db_dremio_password")
    conf["models_folder"] = props.get("models_folder")
    conf["analytics_s3_env_dir"] = props.get("analytics_s3_env_dir").lower()
    conf["emr_kda_s3_bucket"] = props.get("aws_emr_s3_bucket")
    conf["storage_fs"] = props.get("storage_fs")

    if props.get("storage_fs") == "s3":
        conf["aws_key_access"] = props.get("aws_key_access")
        conf["aws_key_secret"] = props.get("aws_key_secret")
        conf["aws_emr_region"] = props.get("aws_emr_region")
    elif props.get("storage_fs") == "hdfs":
        conf["fs_hdfs_host"] = props.get("fs_hdfs_host")
        conf["fs_hdfs_port"] = props.get("fs_hdfs_port")
    elif props.get("storage_fs") == "abs":
        conf["azure_connection_string"] = props.get("azure_connection_string")
    conf["es_host"] = props.get("es_host")
    conf["es_port"] = props.get("es_port")
    conf["mm_index"] = props.get("analytics_model_monitoring_es_index")
    pprint(conf)
    params = base64.b64encode(json.dumps(conf).encode("ascii")).decode("ascii")
    print("-----------------------------------------------------------------------------")
    pprint(params)
    print("-----------------------------------------------------------------------------")
    return params


dag = DAG(
    dag_id,
    schedule_interval=None,
    start_date=days_ago(2),
    default_args={"owner": "leni"},
    tags=["kda", env],
    user_defined_macros={
        "_construct_spark_app_name_": _construct_spark_app_name_,
        "_construct_app_args_": _construct_app_args_
    }
)


create_model = SparkSubmitOperator(
    task_id="create_model",
    dag=dag,
    application=f"local:///opt/spark/work-dir/kda_pyspark.py",
    name="{{_construct_spark_app_name_(dag_run.conf)}}",
    conn_id=connections.get("spark_master"),
    conf={
        "spark.driver.memory": "{{ dag_run.conf['spark_configs']['spark.driver.memory'] }}",
        "spark.executor.instances": "{{ dag_run.conf['spark_configs']['spark.executor.instances'] }}",
        "spark.executor.memory": "{{ dag_run.conf['spark_configs']['spark.executor.memory'] }}",
        "spark.executor.cores": "{{ dag_run.conf['spark_configs']['spark.executor.cores'] }}",
        "spark.default.parallelism": "{{ dag_run.conf['spark_configs']['spark.default.parallelism'] }}",
        "spark.sql.shuffle.partitions": "{{ dag_run.conf['spark_configs']['spark.sql.shuffle.partitions'] }}",
        "spark.dynamicAllocation.enabled": "{{ dag_run.conf['spark_configs']['spark.dynamicAllocation.enabled'] }}",
        "spark.eventLog.enabled": True,
        "spark.eventLog.dir": spark_eventLog_dir,
        spark_driver_volume_claimname: spark_storage_claimname,
        spark_driver_volume_claimpath: spark_storage_claimpath,
        spark_executor_volume_claimname: spark_storage_claimname,
        spark_executor_volume_claimpath: spark_storage_claimpath,
        "spark.kubernetes.driver.pod.name": "{{_construct_spark_app_name_(dag_run.conf)}}",
        "spark.kubernetes.executor.podNamePrefix": "{{_construct_spark_app_name_(dag_run.conf)}}",
        "spark.kubernetes.driver.label.kda-driver": True,
        "spark.kubernetes.executor.label.kda-executor": True,
        "spark.kubernetes.container.image": spark_container_image_kda,
        "spark.kubernetes.authenticate.driver.serviceAccountName": spark_serviceaccount
    },
    application_args=["{{_construct_app_args_(dag_run.conf)}}"]
)


def find_failed_tasks(**context):
    tis_dagrun = context["ti"].get_dagrun().get_task_instances()
    failed_count = sum([True if ti.state == State.FAILED else False for ti in tis_dagrun])
    print(f"There are {failed_count} failed tasks in this execution")
    context["task_instance"].xcom_push(key="status", value=("success" if failed_count == 0 else "failed"))


find_failed = PythonOperator(
    task_id="find_failed",
    python_callable=find_failed_tasks,
    trigger_rule="all_done",
    dag=dag
)

update_status = SimpleHttpOperator(
    dag=dag,
    task_id="update_status",
    http_conn_id=connections.get("analytics_ask_leni_id"),
    method="POST",
    endpoint="/analytics/v1/kda/update-diagnostic-status",
    headers={"Content-Type": "application/json", "Authorization": "Bearer {{ dag_run.conf['token'] }}"},
    data=json.dumps({
        "job_id": "{{ dag_run.conf['jobid'] }}",
        "account_id": "{{ dag_run.conf['account_id'] }}",
        "dataset_id": "{{ dag_run.conf['datasetid'] }}",
        "diagnostic_id": "{{ dag_run.conf['diagnostic_id'] }}",
        "model_id": "{{ dag_run.conf['model_id'] }}",
        "version": "{{ dag_run.conf['version'] }}",
        "job_status": "{{ ti.xcom_pull(task_ids='find_failed', key='status') }}"
    })
)

create_model >> find_failed >> update_status
