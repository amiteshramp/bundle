import os
import json
import sys
from pprint import pprint

from airflow.models import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.http.operators.http import SimpleHttpOperator
from airflow.utils.dates import days_ago
import base64
# Due to utils package import issue do not move the below import line to other location
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
from utils import load_configs, load_connections, validate_schema
from spark_submit import CustomSparkSubmitOperator

props = load_configs(os.path.join(os.path.dirname(os.path.realpath(__file__))))
connections = load_connections(props)

env = props.get("env").replace("-", "_")
spark_storage_claimname = props.get("spark_storage_claimname")
spark_storage_claimpath = props.get("spark_storage_claimpath")
spark_storage_volumetype = props.get("spark_storage_volumetype")
spark_eventLog_dir = props.get("spark_eventLog_dir")
spark_k8s_namespace = props.get("spark_k8s_namespace")
spark_container_image_nudges = props.get("spark_container_image_nudges")
spark_serviceaccount = props.get("spark_serviceaccount")
spark_driver_volume_claimname = f"spark.kubernetes.driver.volumes.{spark_storage_volumetype}.{spark_storage_claimname}.options.claimName"
spark_driver_volume_claimpath = f"spark.kubernetes.driver.volumes.{spark_storage_volumetype}.{spark_storage_claimname}.mount.path"
spark_executor_volume_claimname = f"spark.kubernetes.executor.volumes.{spark_storage_volumetype}.{spark_storage_claimname}.options.claimName"
spark_executor_volume_claimpath = f"spark.kubernetes.executor.volumes.{spark_storage_volumetype}.{spark_storage_claimname}.mount.path"


dag_id = "nudges_ss_validation_pipeline" if not env else "nudges_ss_validation_pipeline_{}".format(env.lower())


def _construct_app_args_(conf):
    source_name = base64.b64encode(conf.get('source_name').encode("ascii")).decode("ascii")
    params = [conf.get("account_id"), conf.get("authentication_token"), conf.get("job_id"), conf.get("time_of_trigger"),
              conf.get("dataset_id"), source_name, conf.get("api_secret"), conf.get("api_key"),
              conf.get("dataset_type"), conf.get("email"), conf.get("version"), conf.get("resource_id")]
    pprint(params)
    return params


def _spark_configs_(spark_configs, stage, job_id):
    print(spark_configs)
    print(type(spark_configs))
    spark_configs = json.loads(spark_configs) if isinstance(spark_configs, str) else spark_configs
    spark_configs = spark_configs.get("SparkConfigs")
    spark_configs["spark.default.parallelism"] = int(spark_configs.get("spark.default.parallelism")) * 2
    spark_configs["spark.sql.shuffle.partitions"] = int(spark_configs.get("spark.sql.shuffle.partitions")) * 2
    print(spark_configs)
    print(type(spark_configs))
    return {
        "spark.driver.memory": spark_configs.get("spark.driver.memory"),
        "spark.executor.instances": spark_configs.get("spark.executor.instances"),
        # "spark.executor.memory": spark_configs.get("spark.executor.memory"),
        # "spark.executor.cores": spark_configs.get("spark.executor.cores"),
        "spark.executor.memory": "20g",
        "spark.executor.cores": 5,
        # "spark.default.parallelism": spark_configs.get("spark.default.parallelism"),
        # "spark.sql.shuffle.partitions": spark_configs.get("spark.sql.shuffle.partitions"),
        "spark.default.parallelism": 1056,
        "spark.sql.shuffle.partitions": 1056,
        "spark.dynamicAllocation.enabled": spark_configs.get("spark.dynamicAllocation.enabled"),
        "spark.eventLog.enabled": True,
        "spark.eventLog.dir": spark_eventLog_dir,
        spark_driver_volume_claimname: spark_storage_claimname,
        spark_driver_volume_claimpath: spark_storage_claimpath,
        spark_executor_volume_claimname: spark_storage_claimname,
        spark_executor_volume_claimpath: spark_storage_claimpath,
        "spark.kubernetes.driver.pod.name": f"{stage.replace('_','-')}-{job_id}",
        "spark.kubernetes.executor.podNamePrefix": f"{stage.replace('_','-')}-{job_id}",
        "spark.kubernetes.driver.label.nudges-drive": True,
        "spark.kubernetes.executor.label.nudges-executor": True,
        "spark.kubernetes.container.image": spark_container_image_nudges,
        "spark.kubernetes.authenticate.driver.serviceAccountName": spark_serviceaccount
    }


# initializing dag object
dag = DAG(
    dag_id,
    schedule_interval=None,
    start_date=days_ago(2),
    default_args={"owner": "leni"},
    tags=["nudges", env],
    user_defined_macros={
        "_construct_app_args_": _construct_app_args_,
        "_spark_configs_": _spark_configs_
    }
)

# validates input
validate_input = PythonOperator(
    task_id="validating_input",
    python_callable=validate_schema,
    op_args=["{{ dag_run.conf['data']|tojson }}"],
    dag=dag
)


get_spark_configs = SimpleHttpOperator(
    task_id="get_spark_configs",
    method="POST",
    http_conn_id=connections.get("analytics_ask_leni_id"),
    endpoint="/analytics/v1/get-route",
    data=json.dumps({
        "job_type": "nudges",
        "account_id": "{{ dag_run.conf['data']['account_id'] }}",
        "activity_name": "{{ dag_run.conf['data']['source_name'] }}"
    }),
    headers={"Content-Type": "application/json"},
    do_xcom_push=True,
    dag=dag
)


nudge_validation = CustomSparkSubmitOperator(
    task_id="nudge_validation",
    dag=dag,
    application=f"local:///opt/spark/work-dir/{props.get('spark_file_ss_validation')}",
    name="nudge_validation",
    conn_id=connections.get("spark_master"),
    conf="{{ _spark_configs_(ti.xcom_pull(key='return_value'), ti.task_id, dag_run.conf['data']['job_id']) }}",
    application_args="{{_construct_app_args_(dag_run.conf['data'])}}"
)

validate_input >> get_spark_configs >> nudge_validation
