import os
import sys
from datetime import timedelta

from airflow.models import DAG
from airflow.operators.dummy import DummyOperator
from airflow.providers.http.operators.http import SimpleHttpOperator
from airflow.operators.python import BranchPythonOperator
from airflow.utils.trigger_rule import TriggerRule
from airflow.utils.dates import datetime

from config_management_pkg.config_management import get_config_data

# Due to utils package import issue do not move the below import line to other location
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
import utils
ROOT_PATH = os.path.join(os.path.dirname(os.path.realpath(__file__)))
#app_env = utils.load_configs(os.path.join(ROOT_PATH, "app.env"))
#source = app_env.get("CONFIG_MANAGEMENT_SOURCE")
#cloud_env_file_path = os.path.join(ROOT_PATH, "app-" + source + ".env")
APP_CONSTANT_MS_NAME = "analytics-ask-leni"
props = get_config_data(path=ROOT_PATH, ms_name=APP_CONSTANT_MS_NAME)

connections = utils.load_connections(props)

env = props.get("env").replace("-", "_")
analytics_s3_env_dir = props["analytics_s3_env_dir"].lower()

http_ask_leni_conn_id = connections.get("analytics_ask_leni_id")
http_forecasting_conn_id = connections.get("analytics_forecasting_id")

fs_prefix = utils.build_fs_path()
dag_id = "forecast" if not env else "forecast_{}".format(env.lower())

dag = DAG(
    dag_id,
    schedule_interval=None,
    start_date=datetime(year=2021, month=6, day=7),
    default_args={"owner": "airflow"},
    tags=["forecast", env],
    max_active_runs=5
)


def check_is_causal(is_causal, **kwargs):
    is_causal = eval(is_causal)
    if is_causal:
        return "causal"
    else:
        return "univariate"


pre_processing = SimpleHttpOperator(
    task_id="pre_processing",
    method="GET",
    http_conn_id=http_ask_leni_conn_id,
    endpoint="/analytics/v2/forecast/pre_processing",
    data={"jobid": "{{ dag_run.conf['jobid'] }}",
          "resourceid": "{{ dag_run.conf['resourceid'] }}",
          "eql_file_path": "{{ dag_run.conf['eql_file_path'] }}",
          "account_id": "{{ dag_run.conf['account_id'] }}"},
    headers={"Authorization": "Bearer {{ dag_run.conf['token'] }}"},
    retries=3,
    retry_delay=timedelta(seconds=10),
    retry_exponential_backoff=True,
    depends_on_past=False,
    task_concurrency=4,
    do_xcom_push=True,
    dag=dag
)

univariate_dummy_op = DummyOperator(task_id="univariate", dag=dag)
causal_dummy_op = DummyOperator(task_id="causal", dag=dag)

check_causal = BranchPythonOperator(
    task_id="check_causal",
    python_callable=check_is_causal,
    op_args=["{{ task_instance.xcom_pull(key='return_value') }}"],
    provide_context=True,
    retries=3,
    retry_delay=timedelta(seconds=10),
    retry_exponential_backoff=True,
    task_concurrency=4,
    dag=dag
)

univariate_api_names = ["ffnn", "arima", "prophet", "exponential-smoothing"]
causal_api_names = ["arimax", "varmax"]
univariate_algorithm_task_output = []
causal_algorithm_task_output = []
algorithm_output_paths = []

consolidation_post_processing_and_nlg = SimpleHttpOperator(
    task_id="consolidation_post_processing_and_nlg",
    method="GET",
    http_conn_id=http_ask_leni_conn_id,
    endpoint="/analytics/v2/forecast/post_processing",
    data={"jobid": "{{ dag_run.conf['jobid'] }}",
          "resourceid": "{{ dag_run.conf['resourceid'] }}",
          "account_id": "{{ dag_run.conf['account_id'] }}",
          "algorithms_ifp": algorithm_output_paths},
    headers={"Authorization": "Bearer {{ dag_run.conf['token'] }}"},
    retries=3,
    retry_delay=timedelta(seconds=10),
    depends_on_past=False,
    trigger_rule=TriggerRule.NONE_FAILED,
    retry_exponential_backoff=True,
    task_concurrency=4,
    dag=dag
)


for name in univariate_api_names:
    name_ = name.replace("-", "_")
    algorithms = SimpleHttpOperator(
        task_id="algorithm_" + name_,
        method="GET",
        http_conn_id=http_forecasting_conn_id,
        endpoint="/analytics-forecast/v1/algorithm/{}".format(name),
        data={"jobid": "{{ dag_run.conf['jobid'] }}",
              "resourceid": "{{ dag_run.conf['resourceid'] }}",
              "account_id": "{{ dag_run.conf['account_id'] }}",
              "input_file_path": fs_prefix + "/{{ dag_run.conf['resourceid'] }}/{{ dag_run.conf['jobid'] }}/pre_processing/output",
              "algo_name": name_},
        headers={"Authorization": "Bearer {{ dag_run.conf['token'] }}"},
        retries=3,
        retry_delay=timedelta(seconds=10),
        retry_exponential_backoff=True,
        depends_on_past=False,
        task_concurrency=4,
        dag=dag
    )
    algorithm_output_paths.append(fs_prefix + "/{{ dag_run.conf['resourceid'] }}/{{ dag_run.conf['jobid'] }}/algorithm_" + name_ + "/output")
    univariate_dummy_op >> algorithms >> consolidation_post_processing_and_nlg
    # univariate_algorithm_task_output.append(algorithms)

for name in causal_api_names:
    name_ = name.replace("-", "_")
    algorithms = SimpleHttpOperator(
        task_id="algorithm_" + name_,
        method="GET",
        http_conn_id=http_forecasting_conn_id,
        endpoint="/analytics-forecast/v1/algorithm/{}".format(name),
        data={"jobid": "{{ dag_run.conf['jobid'] }}",
              "resourceid": "{{ dag_run.conf['resourceid'] }}",
              "account_id": "{{ dag_run.conf['account_id'] }}",
              "input_file_path": fs_prefix + "/{{ dag_run.conf['resourceid'] }}/{{ dag_run.conf['jobid'] }}/pre_processing/output",
              "algo_name": name_},
        headers={"Authorization": "Bearer {{ dag_run.conf['token'] }}"},
        retries=3,
        retry_delay=timedelta(seconds=10),
        retry_exponential_backoff=True,
        depends_on_past=False,
        task_concurrency=4,
        dag=dag
    )
    algorithm_output_paths.append(fs_prefix + "/{{ dag_run.conf['resourceid'] }}/{{ dag_run.conf['jobid'] }}/algorithm_" + name_ + "/output")
    # causal_algorithm_task_output.append(algorithms)
    causal_dummy_op >> algorithms >> consolidation_post_processing_and_nlg

pre_processing >> check_causal >> [causal_dummy_op, univariate_dummy_op]
