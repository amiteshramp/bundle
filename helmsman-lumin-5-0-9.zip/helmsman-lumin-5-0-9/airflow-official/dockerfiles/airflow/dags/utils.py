import json
from jsonschema import validate

from airflow.models import Connection
from airflow.settings import Session

from config_management_pkg.config_management import get_config_data


def upsert_connection(connection, session):
    connection_name = session \
        .query(Connection) \
        .filter(Connection.conn_id == connection.conn_id) \
        .first()

    # FIXME: If host, port, or schema get changed. Remove existing connection id and add new one
    if str(connection_name) == str(connection.conn_id):
        return True
    session.add(connection)
    session.commit()
    return True


def load_configs(app_path):
    return get_config_data(app_path)


def load_connections(props):
    session = Session()
    env = props.get("env")
    connections = {
        "spark_master": spark_master(env, session, props),
        "analytics_ask_leni_id": analytics_common_ms(env, session, props),
        "analytics_forecasting_id": analytics_forecasting_ms(env, session, props),
        "tech_nudges_connection_id": tech_nudges_ms(env, session, props) if props.get("nudges_host") else None,
        "jobs_connection_id": jobs_ms(env, session, props) if props.get("job_server_host") else None
    }
    if not props.get("onpremise_enable"):
        connections["aws_connection_id"] = aws_connection(env, session, props)
    session.commit()
    return connections


def aws_connection(env, session, props):
    creds = {"region_name": props.get("aws_emr_region")}
    aws_access_key_id = props.get("aws_key_access")
    aws_secret_access_key = props.get("aws_key_secret")
    if aws_access_key_id and aws_secret_access_key:
        creds["aws_access_key_id"] = aws_access_key_id
        creds["aws_secret_access_key"] = aws_secret_access_key
    aws_connection_id = "aws_default" if not env else "aws_{}".format(env.lower())
    upsert_connection(Connection(conn_id=aws_connection_id, conn_type="emr", extra=json.dumps(creds)),
                      session)
    return aws_connection_id


def spark_master(env, session, props):
    spark_conn = "spark_master" if not env else "spark_master_{}".format(env.lower())
    spark_conn_extra = {"spark_binary": "spark-submit", "namespace":props.get("spark_k8s_namespace"), "deploy-mode": "cluster"}
    upsert_connection(Connection(conn_id=spark_conn,
                                 conn_type="Spark",
                                 host=props.get("spark_k8s_master"),
                                 extra=json.dumps(spark_conn_extra)),
                      session)
    return spark_conn


def analytics_common_ms(env, session, props):
    analytics_connection_id = "analytics-api" if not env else "analytics-api-{}".format(env.lower())
    upsert_connection(Connection(conn_id=analytics_connection_id, conn_type="http",
                                 schema=props.get("analytics_protocol"),
                                 host=props.get("analytics_host"),
                                 port=props.get("analytics_port")), session)
    return analytics_connection_id


def analytics_forecasting_ms(env, session, props):
    forecasting_connection_id = "forecasting-api" if not env else "forecasting-api-{}".format(env.lower())
    upsert_connection(Connection(conn_id=forecasting_connection_id, conn_type="http",
                                 schema=props.get("analytics_forecasting_protocol"),
                                 host=props.get("analytics_forecasting_host"),
                                 port=props.get("analytics_forecasting_port")), session)
    return forecasting_connection_id


def jobs_ms(env, session, props):
    jobs_connection_id = "jobs-api" if not env else "jobs-api-{}".format(env.lower())
    upsert_connection(Connection(conn_id=jobs_connection_id, conn_type="http",
                                 schema=props.get("job_server_protocol"),
                                 host=props.get("job_server_host"),
                                 port=props.get("job_server_port")), session)
    return jobs_connection_id


def tech_nudges_ms(env, session, props):
    tech_nudges_connection_id = "tech-nudges-api" if not env else "tech-nudges-api-{}".format(env.lower())
    upsert_connection(Connection(conn_id=tech_nudges_connection_id, conn_type="http",
                                 schema=props.get("nudges_protocol"),
                                 host=props.get("nudges_host"),
                                 port=props.get("nudges_port")), session)
    return tech_nudges_connection_id


def validate_schema(data):
    nudges_api_schema = {"definitions": {}, "$schema": "http://json-schema.org/draft-07/schema#",
                         "$id": "https://example.com/object1609414752.json", "title": "Root", "type": "object",
                         "required": ["account_id", "authentication_token", "job_id", "time_of_trigger", "dataset_id",
                                      "source_name", "api_secret", "api_key", "dataset_type", "email", "version",
                                      "resource_id"], "properties": {
            "account_id": {"$id": "#root/account_id", "title": "Account_id", "type": "string", "default": "",
                           "examples": ["5d2d57ff9a558c00017d4dd0"], "pattern": "^.*$"},
            "authentication_token": {"$id": "#root/authentication_token", "title": "Authentication_token",
                                     "type": "string",
                                     "default": "", "examples": ["abcdef123"], "pattern": "^.*$"},
            "job_id": {"$id": "#root/job_id", "title": "Job_id", "type": "string", "default": "",
                       "examples": ["abcdef123"],
                       "pattern": "^.*$"},
            "time_of_trigger": {"$id": "#root/time_of_trigger", "title": "Time_of_trigger", "type": "string",
                                "default": "",
                                "examples": ["2020-10 20T07:00:30.000Z"], "pattern": "^.*$"},
            "dataset_id": {"$id": "#root/dataset_id", "title": "Dataset_id", "type": "string", "default": "",
                           "examples": ["abcdef12345"], "pattern": "^.*$"},
            "source_name": {"$id": "#root/source_name", "title": "Source_name", "type": "string", "default": "",
                            "examples": ["hfd_retail_audit_activity"], "pattern": "^.*$"},
            "api_secret": {"$id": "#root/api_secret", "title": "Api_secret", "type": "string", "default": "",
                           "examples": ["api_secret"], "pattern": "^.*$"},
            "api_key": {"$id": "#root/api_key", "title": "Api_key", "type": "string", "default": "",
                        "examples": ["api_key"], "pattern": "^.*$"},
            "dataset_type": {"$id": "#root/dataset_type", "title": "Dataset_type", "type": "string", "default": "",
                             "examples": ["syndicate"], "pattern": "^.*$"},
            "email": {"$id": "#root/email", "title": "Email", "type": "string", "default": "", "examples": ["1234com"],
                      "pattern": "^.*$"},
            "version": {"$id": "#root/version", "title": "Version", "type": "string", "default": "", "examples": ["2"],
                        "pattern": "^.*$"},
            "resource_id": {"$id": "#root/resource_id", "title": "Resource_id", "type": "string", "default": "",
                            "examples": ["cce044c1-ca95-49ff-b7fd-6eafccb6d6fd"], "pattern": "^.*$"}}}

    return validate(json.loads(data), nudges_api_schema)


def build_fs_path(env=None):
    if env:
        jobs_dir_prefix_paths = ["", env.lower(), "jobs"]
    else:
        jobs_dir_prefix_paths = ["", "jobs"]

    return "/".join(jobs_dir_prefix_paths)
