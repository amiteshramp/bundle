import os
import json
import sys
from pprint import pprint
from airflow.models import DAG
from airflow.operators.python import PythonOperator, BranchPythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.providers.http.operators.http import SimpleHttpOperator
from airflow.utils.dates import days_ago, datetime as dt
from airflow.utils.state import State
import math
import base64
# Due to utils package import issue do not move the below import line to other location
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
from utils import load_configs, load_connections, validate_schema
from spark_submit import CustomSparkSubmitOperator

props = load_configs(os.path.join(os.path.dirname(os.path.realpath(__file__))))
connections = load_connections(props)

env = props.get("env").replace("-", "_")
spark_storage_claimname = props.get("spark_storage_claimname")
spark_storage_claimpath = props.get("spark_storage_claimpath")
spark_storage_volumetype = props.get("spark_storage_volumetype")
spark_eventLog_dir = props.get("spark_eventLog_dir")
spark_k8s_namespace = props.get("spark_k8s_namespace")
spark_container_image_nudges = props.get("spark_container_image_nudges")
spark_serviceaccount = props.get("spark_serviceaccount")
spark_driver_volume_claimname = f"spark.kubernetes.driver.volumes.{spark_storage_volumetype}.{spark_storage_claimname}.options.claimName"
spark_driver_volume_claimpath = f"spark.kubernetes.driver.volumes.{spark_storage_volumetype}.{spark_storage_claimname}.mount.path"
spark_executor_volume_claimname = f"spark.kubernetes.executor.volumes.{spark_storage_volumetype}.{spark_storage_claimname}.options.claimName"
spark_executor_volume_claimpath = f"spark.kubernetes.executor.volumes.{spark_storage_volumetype}.{spark_storage_claimname}.mount.path"
spark_executor_core_limit = 5

dag_id = "nudge_creation_pipeline" if not env else "nudge_creation_pipeline_{}".format(env.lower())


def _construct_app_args_(conf):
    source_name = base64.b64encode(conf.get('source_name').encode("ascii")).decode("ascii")
    params = [conf.get("account_id"), conf.get("authentication_token"), conf.get("job_id"), conf.get("time_of_trigger"),
              conf.get("dataset_id"), source_name, conf.get("api_secret"), conf.get("api_key"),
              conf.get("dataset_type"), conf.get("email"), conf.get("version"), conf.get("resource_id")]
    pprint(params)
    return params


def _spark_configs_(spark_configs, stage, job_id):
    print(spark_configs)
    print(type(spark_configs))
    spark_configs = json.loads(spark_configs) if isinstance(spark_configs, str) else spark_configs
    spark_configs = spark_configs.get("SparkConfigs")
    spark_configs["spark.default.parallelism"] = int(spark_configs.get("spark.default.parallelism")) * 2
    spark_configs["spark.sql.shuffle.partitions"] = int(spark_configs.get("spark.sql.shuffle.partitions")) * 2
    print(spark_configs)
    print(type(spark_configs))
    return {
        "spark.driver.memory": spark_configs.get("spark.driver.memory"),
        "spark.executor.instances": spark_configs.get("spark.executor.instances"),
        # "spark.executor.instances": math.ceil(int(spark_configs.get("spark.executor.instances"))*0.5),
        # "spark.executor.instances": 7 if int(spark_configs.get("spark.executor.instances")) > 7 else spark_configs.get("spark.executor.instances"),
        # "spark.executor.memory": spark_configs.get("spark.executor.memory"),
        # "spark.executor.cores": spark_configs.get("spark.executor.cores"),
        "spark.executor.memory": "20g",
        "spark.executor.cores": 5,
        # "spark.default.parallelism": spark_configs.get("spark.default.parallelism"),
        # "spark.sql.shuffle.partitions": spark_configs.get("spark.sql.shuffle.partitions"),
        "spark.default.parallelism": 1056,
        "spark.sql.shuffle.partitions": 1056,
        "spark.dynamicAllocation.enabled": spark_configs.get("spark.dynamicAllocation.enabled"),
        "spark.eventLog.enabled": True,
        "spark.eventLog.dir": spark_eventLog_dir,
        spark_driver_volume_claimname: spark_storage_claimname,
        spark_driver_volume_claimpath: spark_storage_claimpath,
        spark_executor_volume_claimname: spark_storage_claimname,
        spark_executor_volume_claimpath: spark_storage_claimpath,
        "spark.kubernetes.driver.pod.name": f"{stage.replace('_','-')}-{job_id}",
        "spark.kubernetes.executor.podNamePrefix": f"{stage.replace('_','-')}-{job_id}",
        "spark.kubernetes.driver.label.nudges-drive": True,
        "spark.kubernetes.executor.label.nudges-executor": True,
        "spark.kubernetes.executor.limit.cores": spark_executor_core_limit,
        "spark.kubernetes.container.image": spark_container_image_nudges,
        "spark.kubernetes.authenticate.driver.serviceAccountName": spark_serviceaccount
    }


def _construct_file_path_(conf):
    return f"{props.get('aws_emr_s3_bucket')}/{props.get('analytics_s3_env_dir')}" \
           f"/{props.get('analytics_pyspark_dir_nudges')}/nudge_objects/{conf.get('account_id')}" \
           f"/{conf.get('source_name')}/{conf.get('job_id')}/"


# initializing dag object
dag = DAG(
    dag_id,
    schedule_interval=None,
    start_date=days_ago(2),
    default_args={"owner": "leni"},
    orientation="TB",
    tags=["nudges", env],
    user_defined_macros={
        "_construct_app_args_": _construct_app_args_,
        "_spark_configs_": _spark_configs_,
        "_construct_file_path_": _construct_file_path_
    }
)

# validates input
validate_input = PythonOperator(
    task_id="validating_input",
    python_callable=validate_schema,
    op_args=["{{ dag_run.conf['data']|tojson }}"],
    dag=dag
)

get_spark_configs = SimpleHttpOperator(
    task_id="get_spark_configs",
    method="POST",
    http_conn_id=connections.get("analytics_ask_leni_id"),
    endpoint="/analytics/v1/get-route",
    data=json.dumps({"job_type": "nudges",
                     "account_id": "{{ dag_run.conf['data']['account_id'] }}",
                     "activity_name": "{{ dag_run.conf['data']['source_name'] }}"
                     }),
    headers={"Content-Type": "application/json"},
    do_xcom_push=True,
    dag=dag
)

stages = ["nudge_creation_preprocessing", "nudge_creation_type1", "nudge_creation_type2", "nudge_creation_severity",
          "nudge_creation_postprocessing_type1", "nudge_creation_postprocessing_type2"]

stages_info = {
    "nudge_creation_preprocessing": {"main_file_prop": "spark_file_nudge_preprocess"},
    "nudge_creation_type1": {"main_file_prop": "spark_file_nudge_creation_type1"},
    "nudge_creation_type2": {"main_file_prop": "spark_file_nudge_creation_type2"},
    "nudge_creation_severity": {"main_file_prop": "spark_file_nudge_severity"},
    "nudge_creation_postprocessing_type1": {"main_file_prop": "spark_file_nudge_postprocess_type1"},
    "nudge_creation_postprocessing_type2": {"main_file_prop": "spark_file_nudge_postprocess_type2"}
}

validate_input >> get_spark_configs

tasks = [get_spark_configs]

for stage in stages:
    info = stages_info.get(stage)

    nudge_creation_stage = CustomSparkSubmitOperator(
        task_id=stage,
        dag=dag,
        application=f"local:///opt/spark/work-dir/{props.get(info.get('main_file_prop'))}",
        name=stage,
        conn_id=connections.get("spark_master"),
        conf="{{ _spark_configs_(ti.xcom_pull(key='return_value'), ti.task_id, dag_run.conf['data']['job_id']) }}",
        application_args="{{_construct_app_args_(dag_run.conf['data'])}}",
        status_poll_interval=60,
        executor_config={
            "KubernetesExecutor": {
                "request_cpu": "1",
                "limit_cpu": "1",
                "request_memory": "1000Mi",
                "limit_memory": "1000Mi"
            }
        }
    )
    tasks[-1] >> nudge_creation_stage
    tasks.append(nudge_creation_stage)


nudges_tech_trigger = SimpleHttpOperator(
    task_id="nudges_tech_trigger",
    method="POST",
    http_conn_id=connections.get("tech_nudges_connection_id"),
    endpoint="tech-nudges/v1/nudges-process/trigger",
    data=json.dumps({"jobId": "{{ dag_run.conf['data']['job_id'] }}",
                     "filePath": "{{_construct_file_path_(dag_run.conf['data'])}}",
                     "configId": "{{ dag_run.conf['data']['resource_id'] }}",
                     "src": props.get("storage_fs")}),
    headers={"Content-Type": "application/json",
             "Authorization": "Bearer {{ dag_run.conf['data']['authentication_token'] }}"},
    do_xcom_push=True,
    dag=dag
)


def check_job_status(ti):
    tis_dagrun = ti.get_dagrun().get_task_instances()
    for ti in tis_dagrun:
        if ti.task_id == "nudges_tech_trigger" and ti.state != State.UPSTREAM_FAILED:
            ti.xcom_push(key="nudges_tech_trigger_status", value={
                "account_id": ti.get_dagrun().conf["data"]["account_id"],
                "steps": [{"step_id": "8",
                           "end_datetime": str(dt.now()),
                           "status": "COMPLETED" if ti.state == State.SUCCESS else "FAILED"}],
                "progress_percent": "80"
            })
            return "job_completion_trigger"
    return "skip_job_completion_trigger"


condition_to_update_job = BranchPythonOperator(
    task_id="condition_to_update_job",
    python_callable=check_job_status,
    trigger_rule="all_done",
    dag=dag
)

job_completion_trigger = SimpleHttpOperator(
    task_id="job_completion_trigger",
    method="PUT",
    http_conn_id=connections.get("jobs_connection_id"),
    endpoint="tech-jobs/v2/jobs/{{ dag_run.conf['data']['job_id'] }}/steps",
    data="{{ ti.xcom_pull(task_ids='nudges_tech_trigger', key='nudges_tech_trigger_status')|tojson }}",
    headers={"content-type": "application/json"},
    do_xcom_push=True,
    dag=dag
)

skip_job_completion_trigger = DummyOperator(task_id="skip_job_completion_trigger", dag=dag)

tasks[-1] >> nudges_tech_trigger >> condition_to_update_job >> [job_completion_trigger, skip_job_completion_trigger]
